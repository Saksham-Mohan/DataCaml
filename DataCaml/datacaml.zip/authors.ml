let hours_worked = [6; 6]

